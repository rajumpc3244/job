import React from 'react';
import { Building2 } from 'lucide-react';

const Header = () => {
  return (
    <header className="sticky top-0 bg-white shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Building2 className="h-8 w-8 text-emerald-500" />
            <span className="ml-2 text-2xl font-bold text-emerald-500">USJobFinder</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-emerald-500">Home</a>
            <a href="#" className="text-gray-700 hover:text-emerald-500">About</a>
            <a href="#" className="text-gray-700 hover:text-emerald-500">Jobs</a>
            <a href="#" className="text-gray-700 hover:text-emerald-500">Pages</a>
            <a href="#" className="text-gray-700 hover:text-emerald-500">Contact</a>
          </nav>

          <button className="bg-emerald-500 text-white px-6 py-2 rounded-full hover:bg-emerald-600 transition-colors">
            Apply Here
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;