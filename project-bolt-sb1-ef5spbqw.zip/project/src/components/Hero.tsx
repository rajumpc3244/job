import React from 'react';
import Slideshow from './Slideshow';

const Hero = () => {
  return (
    <div className="relative bg-gradient-to-b from-emerald-50 to-white">
      <Slideshow />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 drop-shadow-sm mb-6">
            Find The Best Startup Job<br />That Fit You
          </h1>
          <p className="max-w-2xl mx-auto text-lg text-gray-800 mb-8">
            Apply Your Best Job Today and take the next step toward a fulfilling career! 
            Explore exciting opportunities that match your skills and passion. 
            Your future starts with a simple click.
          </p>
          <div className="flex justify-center space-x-4">
            <button className="bg-emerald-500 text-white px-8 py-3 rounded-full hover:bg-emerald-600 transition-colors">
              Search A Job
            </button>
            <button className="bg-blue-500 text-white px-8 py-3 rounded-full hover:bg-blue-600 transition-colors">
              Apply Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;