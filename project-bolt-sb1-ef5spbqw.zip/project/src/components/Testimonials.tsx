import React from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    quote: "I am thrilled to apply for a job on this website! It offers incredible opportunities, and I'm excited to showcase my skills and grow professionally. Looking forward to a bright future!",
    name: "Mia Jimmerson",
    title: "Registered Nurse",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100&h=100"
  },
  {
    id: 2,
    quote: "I'm thrilled to have applied for a job through this website! It's a fantastic platform, and I'm excited about the potential opportunities ahead. Looking forward to a great experience!",
    name: "Raymond Binns",
    title: "Software Engineer",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100&h=100"
  },
  // Add more testimonials as needed
];

const Testimonials = () => {
  return (
    <section className="py-16 bg-emerald-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Our Clients Say!!!</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={testimonial.id}
              className={`p-6 rounded-lg ${
                index === 1 
                  ? 'bg-emerald-500 text-white' 
                  : 'bg-white text-gray-900'
              }`}
            >
              <Quote className={`w-8 h-8 mb-4 ${
                index === 1 ? 'text-white' : 'text-emerald-500'
              }`} />
              <p className="mb-6">{testimonial.quote}</p>
              <div className="flex items-center">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className={`text-sm ${
                    index === 1 ? 'text-emerald-100' : 'text-gray-600'
                  }`}>{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;