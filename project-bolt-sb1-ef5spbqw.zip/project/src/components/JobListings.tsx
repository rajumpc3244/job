import React from 'react';
import { CheckCircle2, MapPin, Clock, DollarSign, Heart } from 'lucide-react';

const jobs = [
  {
    id: 1,
    company: 'Fedex',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/FedEx_Express.svg/200px-FedEx_Express.svg.png',
    title: 'Fedex Job',
    location: 'New York, USA',
    type: 'Part Time',
    salary: '$200 - $500',
    sponsor: 'Fedex Group'
  },
  {
    id: 2,
    company: 'CocaCola',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Coca-Cola_logo.svg/200px-Coca-Cola_logo.svg.png',
    title: 'CocaCola Job',
    location: 'Texas, USA',
    type: 'Part Time',
    salary: '$250 - $450',
    sponsor: 'CocaCola Company'
  },
  // Add more jobs as needed
];

const JobListings = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center mb-12">
          <CheckCircle2 className="w-8 h-8 text-emerald-500 mr-3" />
          <h2 className="text-3xl font-bold text-gray-900">Apply Your Best Job Today</h2>
        </div>

        <div className="space-y-6">
          {jobs.map(job => (
            <div key={job.id} className="bg-white border border-gray-200 rounded-lg p-6 flex items-center justify-between hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-6">
                <img src={job.logo} alt={job.company} className="w-16 h-16 object-contain" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                  <div className="flex items-center space-x-4 mt-2 text-gray-600">
                    <span className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {job.location}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {job.type}
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      {job.salary}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">sponsored by {job.sponsor}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <button className="text-emerald-500 hover:text-emerald-600">
                  <Heart className="w-6 h-6" />
                </button>
                <button className="bg-emerald-500 text-white px-6 py-2 rounded-full hover:bg-emerald-600 transition-colors">
                  Apply Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default JobListings;